# OSIRIS Pyto Defender Skeleton
This is a starter structure for GitHub upload.