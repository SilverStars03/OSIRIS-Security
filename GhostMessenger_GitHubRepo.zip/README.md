
# Messenger Voice Journal

This is the App Store submission bundle for the Ghost Messenger app disguised as a journaling tool.

## Files

- `MessengerVoiceJournal.ipa`: Signed iOS app
- `AppStore_Metadata.txt`: Description, keywords, privacy details
- `PrivacyPolicy.html`: Ready to host for Apple's App Store Connect
- `README.md`: This file

## Instructions

1. Clone or upload this repo to GitHub.
2. Use the `.ipa` in Transporter to upload to the App Store.
3. Link `PrivacyPolicy.html` as your public privacy policy URL.
